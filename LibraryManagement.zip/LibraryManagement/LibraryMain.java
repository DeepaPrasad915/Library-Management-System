import java.util.Scanner;

public class LibraryMain {
    public static void main(String[] args) throws ClassNotFoundException {
        Scanner sc = new Scanner(System.in);
        LibraryManager man=new LibraryManager();
        while (true) {
            System.out.println("\n1. Add Book");
            System.out.println("2. View Books");
            System.out.println("3. Search Book By Id");
            System.out.println("4. Search Book By Title");
            System.out.println("5. Issue Book");
            System.out.println("6. Return Book");
            System.out.println("7. Save & Exit");
            System.out.print("Enter Your Choice: ");
            
            try {
                int choice = Integer.parseInt(sc.nextLine());

                switch (choice) {
                    case 1:
                        System.out.println("Enter Book ID: ");
                        int id = Integer.parseInt(sc.nextLine());
                        System.out.println("Enter Title: ");
                        String title = sc.nextLine();
                        System.out.println("Enter Author: ");
                        String author = sc.nextLine();
                        System.out.println("Enter Quantity: ");
                        int quantity = Integer.parseInt(sc.nextLine());
                        
                        man.addBook(id, title, author, quantity);
                        break;

                    case 2:
                        man.displayBooks();
                        break;

                    case 3:
                        System.out.println("Enter Book ID: ");
                        int searchId = Integer.parseInt(sc.nextLine());
                        Book foundById = man.searchBookById(searchId);
                        System.out.println(foundById != null ? foundById : "Book Not Found");
                        break;

                    case 4:
                        System.out.println("Enter Book Title: ");
                        String searchTitle = sc.nextLine();
                        Book foundByTitle = man.searchBookByTitle(searchTitle);
                        System.out.println(foundByTitle != null ? foundByTitle : "Book Not Found");
                        break;

                    case 5:
                        System.out.println("Enter Book ID to issue: ");
                        int issued = Integer.parseInt(sc.nextLine());
                        man.issueBook(issued); // Corrected this line
                        break;

                    case 6:
                        System.out.println("Enter Book ID to Return: ");
                        int returnId = Integer.parseInt(sc.nextLine());
                        man.returnBook(returnId);
                        break;

                    case 7:
                        man.saveToFile();
                        System.out.println("Data saved successfully. Exiting...");
                        sc.close();
                        return; // Exit the program

                    default:
                        System.out.println("Invalid Choice! Try again.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid Input! Please enter a valid number where required.");
            }
        }
    }
}